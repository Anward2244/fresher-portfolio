import React, { useEffect, useRef } from 'react';
import { ArrowDown } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const containerRef = useScrollReveal<HTMLDivElement>();

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY;
        const opacity = Math.max(1 - scrollY / 500, 0);
        const translateY = scrollY * 0.3;
        
        heroRef.current.style.opacity = opacity.toString();
        heroRef.current.style.transform = `translateY(${translateY}px)`;
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToAbout = () => {
    const aboutSection = document.getElementById('about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home" 
      className="min-h-screen flex items-center justify-center relative bg-gradient-to-b from-secondary-50 to-primary-50 overflow-hidden bg-hero-pattern"
    >
      <div 
        ref={heroRef} 
        className="container mx-auto text-center transition-all duration-200 ease-out"
      >
        <div 
          ref={containerRef} 
          className="max-w-3xl mx-auto reveal"
        >
          <div className="w-40 h-40 md:w-48 md:h-48 mx-auto mb-8 rounded-full overflow-hidden border-4 border-white shadow-lg relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary-600/30 to-accent-500/30 mix-blend-overlay z-10"></div>
            <img 
              src="https://scontent.fhyd14-1.fna.fbcdn.net/v/t39.30808-6/495018564_1018431177052572_6698900904131678351_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=1eOpTfnCpJwQ7kNvwHDEaAf&_nc_oc=AdnCX9ofmhdwYm07cu2nRnmLxM7kDdJhwwQvRuqQbqAx_o3LtPGrTQkI0-ceD3hGd4NiQAtpefQHcZkWVRk4NkUT&_nc_zt=23&_nc_ht=scontent.fhyd14-1.fna&_nc_gid=W_EJrhyGAQfz-ulqfECNIw&oh=00_AfEvyf2RAq3QlQFMHOLfKp-4Zwg_x9B2hmB2nTX-lQJlpQ&oe=681B887A" 
              alt="Anwar Dudekula" 
              className="w-full h-full object-cover"
            />
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-secondary-900 mb-4 leading-tight tracking-tight">
            Anwar Dudekula
          </h1>
          
          <p className="text-xl md:text-2xl text-primary-600 font-medium mb-6 animate-slide-up">
            3D Artist & Software Developer
          </p>
          
          <p className="text-lg text-secondary-700 max-w-2xl mx-auto mb-10 leading-relaxed">
            A creative professional specializing in 3D modeling, animation, and graphic design. 
            Bringing imagination to life through stunning visuals and compelling digital artistry.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a 
              href="#contact" 
              className="btn-primary flex items-center justify-center space-x-2 hover:translate-y-[-2px] transition-transform"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              <span>Hire Me</span>
            </a>
            <a 
              href="#projects" 
              className="btn-secondary flex items-center justify-center space-x-2 hover:translate-y-[-2px] transition-transform"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              <span>View My Work</span>
            </a>
          </div>
        </div>
      </div>
      
      <button 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-10 h-10 flex items-center justify-center bg-white rounded-full shadow-md text-secondary-600 hover:text-primary-600 transition-colors animate-bounce"
        onClick={scrollToAbout}
        aria-label="Scroll down"
      >
        <ArrowDown size={20} />
      </button>

      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
};

export default Hero;