import React, { useEffect } from 'react';
import { Palette, Box, Layers, Monitor, Film, Lightbulb } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';
import useSkillProgress from '../hooks/useSkillProgress';

interface Skill {
  name: string;
  level: number;
  category: string;
  icon: React.ReactNode;
}

const Skills: React.FC = () => {
  const leftColRef = useScrollReveal<HTMLDivElement>();
  const rightColRef = useScrollReveal<HTMLDivElement>();
  const softSkillsRef = useScrollReveal<HTMLDivElement>();
  
  useSkillProgress();

  const skills: Skill[] = [
    { name: '3D Modeling', level: 90, category: '3D Skills', icon: <Box size={20} /> },
    { name: 'Texturing', level: 85, category: '3D Skills', icon: <Layers size={20} /> },
    { name: 'Animation', level: 80, category: '3D Skills', icon: <Film size={20} /> },
    { name: 'Blender', level: 80, category: 'Software', icon: <Box size={20} /> },
    { name: 'Photoshop', level: 90, category: 'Software', icon: <Palette size={20} /> },
    { name: 'Illustrator', level: 85, category: 'Software', icon: <Palette size={20} /> },
    { name: 'Davinci Resolve', level: 75, category: 'Software', icon: <Film size={20} /> },
    { name: 'UV Mapping', level: 85, category: '3D Skills', icon: <Layers size={20} /> },
    { name: 'Lighting', level: 80, category: '3D Skills', icon: <Lightbulb size={20} /> },
     { name: 'Python', level: 75, category: 'Technical Skills', icon: <Film size={20} /> },
    { name: 'C', level: 70, category: 'Technical Skills', icon: <Film size={20} /> },
    { name: 'SQL', level: 75, category: 'Technical Skills', icon: <Film size={20} /> },
    { name: 'Java', level: 70, category: 'Technical Skills', icon: <Film size={20} /> },
    { name: 'HTML', level: 65, category: 'Technical Skills', icon: <Film size={20} /> },
    { name: 'CSS', level: 65, category: 'Technical Skills', icon: <Film size={20} /> },
  ];

  const categories = [...new Set(skills.map(skill => skill.category))];
  const leftCategories = categories.slice(0, Math.ceil(categories.length / 2));
  const rightCategories = categories.slice(Math.ceil(categories.length / 2));

  return (
    <section id="skills" className="py-16 md:py-24 bg-secondary-50">
      <div className="container mx-auto">
        <h2 className="section-title">Skills</h2>
        <div className="section-divider"></div>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div ref={leftColRef} className="reveal">
              {leftCategories.map((category, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md p-6 mb-8">
                  <h3 className="text-xl font-semibold text-secondary-900 mb-6">{category}</h3>
                  <div className="space-y-6">
                    {skills
                      .filter(skill => skill.category === category)
                      .map((skill, skillIndex) => (
                        <div key={skillIndex} className="space-y-2 skill-progress" style={{ "--progress-width": `${skill.level}%` } as React.CSSProperties}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="text-primary-600">{skill.icon}</span>
                              <span className="font-medium text-secondary-700">{skill.name}</span>
                            </div>
                            <span className="text-sm text-secondary-500">{skill.level}%</span>
                          </div>
                          <div className="w-full h-2 bg-secondary-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary-600 rounded-full bar"
                            ></div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>

            <div ref={rightColRef} className="reveal">
              {rightCategories.map((category, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md p-6 mb-8">
                  <h3 className="text-xl font-semibold text-secondary-900 mb-6">{category}</h3>
                  <div className="space-y-6">
                    {skills
                      .filter(skill => skill.category === category)
                      .map((skill, skillIndex) => (
                        <div key={skillIndex} className="space-y-2 skill-progress" style={{ "--progress-width": `${skill.level}%` } as React.CSSProperties}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="text-primary-600">{skill.icon}</span>
                              <span className="font-medium text-secondary-700">{skill.name}</span>
                            </div>
                            <span className="text-sm text-secondary-500">{skill.level}%</span>
                          </div>
                          <div className="w-full h-2 bg-secondary-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary-600 rounded-full bar"
                            ></div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div ref={softSkillsRef} className="mt-12 bg-white rounded-lg shadow-md p-6 reveal">
            <h3 className="text-xl font-semibold text-secondary-900 mb-6">Soft Skills</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {['Creativity', 'Attention to Detail', 'Time Management', 'Communication', 'Teamwork', 'Project Management', 'Visual Storytelling'].map((skill, index) => (
                <div 
                  key={index} 
                  className="bg-secondary-50 rounded-lg px-4 py-3 text-center border border-secondary-200 hover:border-primary-500 hover:bg-primary-50 transition-colors duration-200 hover:scale-105 transform"
                >
                  <span className="text-secondary-700">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;