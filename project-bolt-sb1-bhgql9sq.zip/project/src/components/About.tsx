import React from 'react';
import { GraduationCap, Briefcase, Award } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';

const About: React.FC = () => {
  const leftColRef = useScrollReveal<HTMLDivElement>();
  const rightColRef = useScrollReveal<HTMLDivElement>();

  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto">
        <h2 className="section-title">About Me</h2>
        <div className="section-divider"></div>
        
        <div className="max-w-3xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            <div ref={leftColRef} className="space-y-6 reveal">
              <p className="text-secondary-700 leading-relaxed mb-4">
                I'm a skilled 3D artist and graphic designer with a passion for creating 
                immersive visual experiences. My expertise spans across 3D modeling, texturing, 
                animation, and graphic design, allowing me to bring creative concepts to life.
              </p>
              <p className="text-secondary-700 leading-relaxed mb-4">
                With proficiency in tools like Blender and Davinci Resolve, I combine technical precision with artistic vision to deliver 
                high-quality visual content that exceeds expectations.
              </p>
              <p className="text-secondary-700 leading-relaxed">
                When I'm not creating digital art, I'm exploring new design trends, experimenting 
                with emerging 3D technologies, and seeking inspiration from various art forms to 
                enhance my creative process.
              </p>
            </div>
            
            <div ref={rightColRef} className="space-y-6 reveal">
              <h3 className="text-2xl font-semibold text-secondary-900 mb-6">Education</h3>
              
              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-secondary-900 mb-1">MARCH 2019</h3>
                  <p className="text-secondary-700 mb-1">X, BOARD OF SECONDARY EDUCATION,A.P</p>
                  <p className="text-secondary-500 text-sm">SRI SHANTHINIKETHAN EM SCHOOL,GPA : 9.7/10</p>
                </div>
              </div>
              
                            <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-secondary-900 mb-1">JUNE 2022</h3>
                  <p className="text-secondary-700 mb-1">DIPLOMA, STATE BOARD OF TECHNICAL EDUCATION AND TRAINING ,A.P</p>
                  <p className="text-secondary-500 text-sm">ESC GOVERNMENT POLYTECHNIC COLLEGE ,MARKS : 74.98%</p>
                </div>
              </div>
              
                          <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-secondary-900 mb-1">JUNE 2025</h3>
                  <p className="text-secondary-700 mb-1">B.TECH (EEE), JAWAHARLAL NEHRU TECHNOLOGICAL UNIVERSITY
ANANTAPUR,A.P</p>
                  <p className="text-secondary-500 text-sm">RAJEEV GANDHI MEMORIAL OF ENGINEERING AND TECHNOLOGY,CGPA : 8.3</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;