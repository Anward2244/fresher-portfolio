import React, { useState } from 'react';
import { Mail, MapPin, Phone, Send, Linkedin, Github, Instagram } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';

const Contact: React.FC = () => {
  const leftColRef = useScrollReveal<HTMLDivElement>();
  const formRef = useScrollReveal<HTMLDivElement>();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const [formStatus, setFormStatus] = useState<{
    submitted: boolean;
    success: boolean;
    message: string;
  } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      setFormStatus({
        submitted: true,
        success: false,
        message: 'Please fill in all required fields.'
      });
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setFormStatus({
        submitted: true,
        success: false,
        message: 'Please enter a valid email address.'
      });
      return;
    }
    
    setFormStatus({
      submitted: true,
      success: true,
      message: 'Your message has been sent successfully! I will get back to you soon.'
    });
    
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto">
        <h2 className="section-title">Contact Me</h2>
        <div className="section-divider"></div>
        
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          <div ref={leftColRef} className="reveal">
            <h3 className="text-2xl font-semibold text-secondary-900 mb-6">Get In Touch</h3>
            <p className="text-secondary-700 mb-8">
              I'm currently available for freelance work and full-time positions. 
              If you have a project that needs some creative touch, or if you'd like 
              to discuss potential opportunities, feel free to reach out!
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">Email</h4>
                  <a href="mailto:danwar2805@gmail.com" className="text-secondary-700 hover:text-primary-600 transition-colors">
                    danwar2805@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">Phone</h4>
                  <a href="tel:+916302167307" className="text-secondary-700 hover:text-primary-600 transition-colors">
                    +91 6302167307
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">Location</h4>
                  <p className="text-secondary-700">
                    Nandyal, Andhra Pradesh, India
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <Linkedin size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">LinkedIn</h4>
                  <a href="www.linkedin.com/in/dudekula-anwar-08139033b" target="_blank" rel="noopener noreferrer" className="text-secondary-700 hover:text-primary-600 transition-colors">
                    Dudekula Anwar
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <Github size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">GitHub</h4>
                  <a href="https://github.com/Anward2244" target="_blank" rel="noopener noreferrer" className="text-secondary-700 hover:text-primary-600 transition-colors">
                    Anward2244
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4 hover:translate-x-1 transition-transform duration-300">
                <div className="icon-container-sm">
                  <Instagram size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-secondary-900">Instagram</h4>
                  <a href="https://www.instagram.com/anwar_renders_/" target="_blank" rel="noopener noreferrer" className="text-secondary-700 hover:text-primary-600 transition-colors">
                    @anwar_renders_
                  </a>
                </div>
              </div>
            </div>
            
            <div className="p-6 bg-primary-50 rounded-lg border border-primary-100">
              <h4 className="text-lg font-medium text-secondary-900 mb-2">Availability</h4>
              <p className="text-secondary-700">
                Currently available for freelance projects and full-time opportunities. 
                My typical response time is within 24 hours.
              </p>
            </div>
          </div>
          
          <div ref={formRef} className="bg-secondary-50 rounded-lg p-6 shadow-md reveal">
            <h3 className="text-2xl font-semibold text-secondary-900 mb-6">Send Me a Message</h3>
            
            {formStatus && (
              <div 
                className={`p-4 mb-6 rounded-lg ${
                  formStatus.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}
              >
                {formStatus.message}
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-secondary-700 mb-1">
                  Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Your Name"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-secondary-700 mb-1">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Your Email"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-secondary-700 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Subject"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-secondary-700 mb-1">
                  Message <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={5}
                  className="input-field"
                  placeholder="Your Message"
                  required
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="flex items-center space-x-2 px-6 py-3 bg-primary-600 text-white font-medium rounded-lg shadow-md hover:bg-primary-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary-600 focus:ring-opacity-50 w-full justify-center hover:translate-y-[-2px]"
              >
                <span>Send Message</span>
                <Send size={16} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;