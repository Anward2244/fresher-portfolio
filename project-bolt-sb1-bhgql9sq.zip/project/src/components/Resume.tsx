import React from 'react';
import { FileText, Download, Calendar, Briefcase, GraduationCap } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';

const Resume: React.FC = () => {
  const resumeRef = useScrollReveal<HTMLDivElement>();
  
  const experiences = [
    {
      title: "3D artist",
      company: "Self-employed",
      period: "July 2021 - Present",
      description: "Learnt Blender software myself by taking courses, attending workshops."
    },
    {
      title: "Freelance Web Developer",
      company: "Self-employed",
      period: "January 2022 - Present",
      description: "Designed and developed custom websites for small businesses and individuals. Created responsive layouts, implemented interactive features, and ensured cross-browser compatibility. Managed client relationships and project timelines."
    }
  ];

  const education = [
    {
      degree: "CYBER SECURITY VIRTUAL INTERNSHIP",
      institution: "Paloalto Networks",
      period: "September 2023 - November 2023",
      details: "Short-term Internship"
    },
    {
      degree: "Electric Vehicle",
      institution: "SkillDzire",
      period: "December 2024 - March 2025",
      details: "Long-term Internship."
    }
  ];

  return (
    <section id="resume" className="py-16 md:py-24 bg-secondary-50">
      <div className="container mx-auto">
        <h2 className="section-title">Resume</h2>
        <div className="section-divider"></div>
        
        <div className="flex justify-center mb-10">
          <a 
            href="#" 
            className="btn-primary flex items-center space-x-2 hover:translate-y-[-2px] transition-transform duration-300"
            aria-label="Download resume"
          >
            <FileText size={20} />
            <span>Download Resume</span>
            <Download size={16} />
          </a>
        </div>
        
        <div ref={resumeRef} className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8 reveal">
          <div className="mb-12">
            <div className="flex items-center space-x-2 mb-6">
              <Briefcase size={24} className="text-primary-600" />
              <h3 className="text-2xl font-bold text-secondary-900">Experience</h3>
            </div>
            
            <div className="space-y-8">
              {experiences.map((exp, index) => (
                <div key={index} className="relative pl-8 border-l-2 border-secondary-200 hover:border-primary-500 transition-colors duration-300">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary-600"></div>
                  
                  <div className="hover:translate-x-1 transition-transform duration-300">
                    <h4 className="text-lg font-semibold text-secondary-900">{exp.title}</h4>
                    <p className="text-secondary-700 font-medium">{exp.company}</p>
                    <div className="flex items-center space-x-1 text-sm text-secondary-500 mb-2">
                      <Calendar size={14} />
                      <span>{exp.period}</span>
                    </div>
                    <p className="text-secondary-600">{exp.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <GraduationCap size={24} className="text-primary-600" />
              <h3 className="text-2xl font-bold text-secondary-900">Internships</h3>
            </div>
            
            <div className="space-y-8">
              {education.map((edu, index) => (
                <div key={index} className="relative pl-8 border-l-2 border-secondary-200 hover:border-primary-500 transition-colors duration-300">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary-600"></div>
                  
                  <div className="hover:translate-x-1 transition-transform duration-300">
                    <h4 className="text-lg font-semibold text-secondary-900">{edu.degree}</h4>
                    <p className="text-secondary-700 font-medium">{edu.institution}</p>
                    <div className="flex items-center space-x-1 text-sm text-secondary-500 mb-2">
                      <Calendar size={14} />
                      <span>{edu.period}</span>
                    </div>
                    <p className="text-secondary-600">{edu.details}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;