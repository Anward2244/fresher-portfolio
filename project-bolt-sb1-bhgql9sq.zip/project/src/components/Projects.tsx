import React, { useState } from 'react';
import { ExternalLink, Github } from 'lucide-react';
import useScrollReveal from '../hooks/useScrollReveal';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  tags: string[];
  instagramUrl: string;
  githubUrl: string;
  liveUrl: string;
}

const Projects: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const projectsRef = useScrollReveal<HTMLDivElement>();
  
  const projects: Project[] = [
    {
      id: 1,
      title: "Vinayaka Chavithi Animation",
      description: "An animaton of vinayaka made for the occasion of Vinayaka Chavithi.",
      image: "https://scontent.fhyd14-2.fna.fbcdn.net/v/t39.30808-6/481998327_976885147873842_6912762195193126837_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=127cfc&_nc_ohc=deZZCr0TSqoQ7kNvwHfT_xP&_nc_oc=AdnpsWDL22oXKBVhGdugKASwkh5p_QVHW4wfigJY-W4b_FlRnU2zUf2XyHMQMr_W7op_g9wzrlZYt8SOBVnrS-MM&_nc_zt=23&_nc_ht=scontent.fhyd14-2.fna&_nc_gid=xr12Hf915PhXlRaduR_0sg&oh=00_AfFnfKRntIc5crEamsaCGpRPecEaPTsqGZQ1x9AfsbOdww&oe=681BA685",
      tags: ["Blender", "Davinci Resolve"],
      InstagramUrl: "https://www.instagram.com/reel/C_lq7WjhSQt/",
    },
    {
      id: 2,
      title: "Dual-Axis Solar Tracking System with Automatic Streetlight",
      description: "A Solar tracking system which can rotate in both Horizontal and vertical axis to obtain more effiency than static solar panel.",
      image: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjXO3sx4HgvT1V5C71b5B6X8tI3g4Er9WSZhTmDbGMFKy-Okxv1KblMCjhq9FsjR81OmUKJSLaRuEQRHTOI3eabM4eA-LNSd8925nT5O71lSWxdnOt1TqOmApvlcqhhzr83ZpnNgBHr14TzqwyxyzvnyI147mC-vMBmjJtH_J-XJJVa5j828WlATI-NDDy-/s640/what-is-solar-tracking-system.png",
      tags: ["Arduino", "Embedded C"],
    },
    {
      id: 3,
      title: "Portfolio Website",
      description: "A responsive personal portfolio website showcasing projects, skills, and contact information with a modern design.",
      image: "https://images.pexels.com/photos/5483077/pexels-photo-5483077.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      tags: ["HTML", "CSS", "JavaScript"],
      githubUrl: "https://github.com",
      liveUrl: "https://example.com"
    }
  ];

  const filters = ['All', 'React', 'JavaScript', 'TypeScript', 'Node.js', 'CSS', 'HTML', 'Blender', 'Davinci Resolve'];

  const filteredProjects = activeFilter === 'All' 
    ? projects 
    : projects.filter(project => project.tags.includes(activeFilter));

  return (
    <section id="projects" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto">
        <h2 className="section-title">Projects</h2>
        <div className="section-divider"></div>
        
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {filters.map((filter, index) => (
            <button
              key={index}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-300 ${
                activeFilter === filter 
                  ? 'bg-primary-600 text-white shadow-md' 
                  : 'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
              }`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        
        <div ref={projectsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 reveal">
          {filteredProjects.map((project) => (
            <div 
              key={project.id} 
              className="project-card group"
            >
              <div className="relative h-60 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-secondary-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-secondary-900 mb-2 group-hover:text-primary-600 transition-colors">{project.title}</h3>
                
                <p className="text-secondary-700 mb-4">{project.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex} 
                      className="tag"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex space-x-4">
                  <a 
                    href={project.githubUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center space-x-1 text-secondary-700 hover:text-primary-600 transition-colors"
                    aria-label={`View ${project.title} code on GitHub`}
                  >
                    <Github size={18} />
                    <span>Code</span>
                  </a>
                  
                  <a 
                    href={project.liveUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center space-x-1 text-secondary-700 hover:text-primary-600 transition-colors"
                    aria-label={`View ${project.title} live demo`}
                  >
                    <ExternalLink size={18} />
                    <span>Live Demo</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;