import React from 'react';
import { Github, Linkedin, Twitter, Mail, Instagram} from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <footer className="bg-secondary-900 text-white py-12">
      <div className="container mx-auto">
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-bold mb-6">Anwar Dudekula</h2>
          
          <div className="flex space-x-6 mb-8">
            <a 
              href="https://github.com/Anward2244" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-secondary-300 hover:text-primary-400 transition-colors"
              aria-label="GitHub"
            >
              <Github size={24} />
            </a>
            <a 
              href="www.linkedin.com/in/dudekula-anwar-08139033b" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-secondary-300 hover:text-primary-400 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin size={24} />
            </a>
            <a 
              href="https://www.instagram.com/anwar_renders_/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-secondary-300 hover:text-primary-400 transition-colors"
              aria-label="Instagram"
            >
              <Instagram size={24} />
            </a>
            <a 
              href="mailto:danwar2805@gmail.com" 
              className="text-secondary-300 hover:text-primary-400 transition-colors"
              aria-label="Email"
            >
              <Mail size={24} />
            </a>
          </div>
          
          <nav className="mb-8">
            <ul className="flex flex-wrap justify-center gap-6">
              <li>
                <a 
                  href="#home" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('home');
                  }}
                >
                  Home
                </a>
              </li>
              <li>
                <a 
                  href="#about" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('about');
                  }}
                >
                  About
                </a>
              </li>
              <li>
                <a 
                  href="#skills" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('skills');
                  }}
                >
                  Skills
                </a>
              </li>
              <li>
                <a 
                  href="#projects" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('projects');
                  }}
                >
                  Projects
                </a>
              </li>
              <li>
                <a 
                  href="#resume" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('resume');
                  }}
                >
                  Resume
                </a>
              </li>
              <li>
                <a 
                  href="#contact" 
                  className="text-secondary-300 hover:text-primary-400 transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('contact');
                  }}
                >
                  Contact
                </a>
              </li>
            </ul>
          </nav>
          
          <div className="text-secondary-400 text-sm text-center">
            <p>&copy; {currentYear} Anwar Dudekula. All rights reserved.</p>
            <p className="mt-1">
              3D Artist & Software Developer
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;